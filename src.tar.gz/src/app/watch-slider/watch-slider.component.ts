import { Component, OnInit } from '@angular/core';
import { Options } from 'ng5-slider';

@Component({
  selector: 'app-watch-slider',
  templateUrl: './watch-slider.component.html',
  styleUrls: ['./watch-slider.component.scss']
})
export class WatchSliderComponent implements OnInit {
  minValue: number = 1961;
  maxValue: number = 2018;
  options: Options = {
    floor: 1961,
    ceil: 2018,
    step: 1,
    ticksArray: [1961, 1975, 1989, 2003, 2018],
    showTicksValues: true
  };
  constructor() { }

  ngOnInit() {
  }

}

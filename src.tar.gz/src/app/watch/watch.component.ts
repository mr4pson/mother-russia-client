import { Component, OnInit } from '@angular/core';
import { Watch } from '../watch';
import { WATCHES } from '../mock-watches';

@Component({
  selector: 'app-watch',
  templateUrl: './watch.component.html',
  styleUrls: ['./watch.component.css']
})
export class WatchComponent implements OnInit {
  watches = WATCHES;
  constructor() { }

  ngOnInit() {
  }

}

import { Watch } from './watch';

export const WATCHES: Watch[] = [
  { id: 1, name: 'The Brother', preview: 'brother.png', year: 1997 },
  { id: 2, name: 'The Brother 2', preview: 'brother_2.png', year: 2000 },
  { id: 3, name: 'War', preview: 'war.png', year: 2002 },
  { id: 4, name: 'Dead Man\'s Bluff' , preview: 'dead_mans_bluff.png', year: 2005 },
  { id: 5, name: 'Bimmer', preview: 'bimmer.png', year: 2003 },
  { id: 6, name: 'Mongol: The Rise of Genghis Khan', preview: 'mongol_the_rise_of_genghis_khan.png', year: 2007 },
  { id: 7, name: 'The Admiral', preview: 'the_admiral.png', year: 2008 },
];
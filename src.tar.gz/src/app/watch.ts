export class Watch {
    id: number;
    name: string;
    preview: string;
    year: number;
  }